@extends('layouts.app')

@section('title', 'PTV-POS')

@section('content')
<div class="space-y-4">
    <h2 class="text-2xl font-bold text-gray-900">PTV-POS</h2>
    <p class="text-sm text-gray-500">Modulo de punto de venta.</p>

    <div class="flex gap-2">
        <a href="{{ route('ptvpos.pos') }}" class="rounded bg-indigo-600 px-3 py-2 text-sm font-semibold text-white">Ir al POS</a>
        <a href="{{ route('ptvpos.open') }}" class="rounded bg-emerald-600 px-3 py-2 text-sm font-semibold text-white">Abrir Caja</a>
        <a href="{{ route('ptvpos.close') }}" class="rounded bg-amber-600 px-3 py-2 text-sm font-semibold text-white">Cerrar Caja</a>
        <a href="{{ route('ptvpos.admin.registers.index') }}" class="rounded bg-gray-700 px-3 py-2 text-sm font-semibold text-white">Cajas</a>
    </div>
</div>
@endsection

