@extends('layouts.app')

@section('title', 'PTV-POS')

@section('content')
<div class="grid grid-cols-1 gap-6 lg:grid-cols-3">
    <div class="lg:col-span-2 space-y-4">
        <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
            <label class="block text-sm font-medium text-gray-700">Barcode</label>
            <input id="barcode-input" type="text" class="mt-1 w-full rounded border border-gray-300 px-3 py-2" placeholder="Escanear codigo de barras">
            <p id="scan-error" class="mt-2 text-sm text-red-600 hidden"></p>
        </div>

        <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
            <table class="min-w-full text-sm" id="cart-table">
                <thead class="bg-gray-50 text-gray-600">
                    <tr>
                        <th class="px-4 py-3 text-left">Producto</th>
                        <th class="px-4 py-3 text-right">Precio</th>
                        <th class="px-4 py-3 text-right">Cantidad</th>
                        <th class="px-4 py-3 text-right">Subtotal</th>
                        <th class="px-4 py-3 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody id="cart-body"></tbody>
            </table>
        </div>
    </div>

    <div class="space-y-4">
        <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm space-y-2">
            <div class="flex justify-between text-sm">
                <span>Subtotal</span>
                <span id="subtotal">$0.00</span>
            </div>
            <div class="flex justify-between text-sm">
                <span>IVA 13%</span>
                <span id="tax">$0.00</span>
            </div>
            <div class="flex justify-between font-semibold">
                <span>Total</span>
                <span id="total">$0.00</span>
            </div>
        </div>

        <form id="checkout-form" method="POST" action="{{ route('ptvpos.checkout') }}" class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm space-y-3">
            @csrf
            <input type="hidden" name="document_type" value="ticket">
            <input type="hidden" name="admin_password" id="admin-password">
            <div>
                <label class="block text-sm font-medium text-gray-700">Efectivo recibido</label>
                <input type="number" step="0.01" min="0" name="cash_received" class="mt-1 w-full rounded border border-gray-300 px-3 py-2">
            </div>
            <button class="w-full rounded bg-emerald-600 px-4 py-2 text-sm font-semibold text-white">Cobrar</button>
        </form>
    </div>
</div>

<div id="admin-modal" class="fixed inset-0 hidden items-center justify-center bg-black/50">
    <div class="rounded-lg bg-white p-4 w-full max-w-sm">
        <h3 class="text-lg font-semibold">Clave de administrador</h3>
        <p class="text-sm text-gray-500">Se requiere para cambiar precios.</p>
        <input type="password" id="admin-pass-input" class="mt-3 w-full rounded border border-gray-300 px-3 py-2">
        <div class="mt-3 flex justify-end gap-2">
            <button type="button" id="admin-cancel" class="rounded border px-3 py-2">Cancelar</button>
            <button type="button" id="admin-confirm" class="rounded bg-indigo-600 px-3 py-2 text-white">Validar</button>
        </div>
        <p id="admin-error" class="mt-2 text-sm text-red-600 hidden"></p>
    </div>
</div>
@endsection

@section('scripts')
<script>
const cart = new Map();
const barcodeInput = document.getElementById('barcode-input');
const cartBody = document.getElementById('cart-body');
const scanError = document.getElementById('scan-error');
const adminModal = document.getElementById('admin-modal');
const adminPassInput = document.getElementById('admin-pass-input');
const adminError = document.getElementById('admin-error');
const adminPasswordField = document.getElementById('admin-password');

function money(value) {
    return '$' + value.toFixed(2);
}

function recalcTotals() {
    let subtotal = 0;
    cart.forEach(item => {
        subtotal += item.price * item.quantity;
    });
    const tax = subtotal * 0.13;
    const total = subtotal + tax;
    document.getElementById('subtotal').textContent = money(subtotal);
    document.getElementById('tax').textContent = money(tax);
    document.getElementById('total').textContent = money(total);
}

function renderCart() {
    cartBody.innerHTML = '';
    cart.forEach((item, id) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="px-4 py-2">${item.name}</td>
            <td class="px-4 py-2 text-right">
                <input type="number" step="0.01" value="${item.price.toFixed(2)}" data-id="${id}" class="price-input w-24 rounded border px-2 py-1 text-right">
            </td>
            <td class="px-4 py-2 text-right">${item.quantity}</td>
            <td class="px-4 py-2 text-right">${money(item.price * item.quantity)}</td>
            <td class="px-4 py-2 text-right">
                <button type="button" data-id="${id}" class="remove-item text-red-600">Quitar</button>
            </td>
        `;
        cartBody.appendChild(tr);
    });
    recalcTotals();
}

async function scanBarcode(code) {
    scanError.classList.add('hidden');
    const res = await fetch("{{ route('ptvpos.scan') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ barcode: code })
    });
    if (!res.ok) {
        const data = await res.json();
        scanError.textContent = data.message || 'Error';
        scanError.classList.remove('hidden');
        return;
    }
    const product = await res.json();
    const current = cart.get(product.id);
    if (current) {
        current.quantity += 1;
    } else {
        cart.set(product.id, { ...product, quantity: 1 });
    }
    renderCart();
}

barcodeInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        const code = barcodeInput.value.trim();
        if (code) {
            scanBarcode(code);
            barcodeInput.value = '';
        }
    }
});

cartBody.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove-item')) {
        const id = parseInt(e.target.dataset.id, 10);
        cart.delete(id);
        renderCart();
    }
});

cartBody.addEventListener('change', (e) => {
    if (e.target.classList.contains('price-input')) {
        adminModal.classList.remove('hidden');
        adminError.classList.add('hidden');
    }
});

document.getElementById('admin-cancel').addEventListener('click', () => {
    adminModal.classList.add('hidden');
});

document.getElementById('admin-confirm').addEventListener('click', async () => {
    const password = adminPassInput.value;
    const res = await fetch("{{ route('ptvpos.adminAuth') }}", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ password })
    });
    if (!res.ok) {
        adminError.textContent = 'Clave invalida';
        adminError.classList.remove('hidden');
        return;
    }
    adminPasswordField.value = password;
    adminModal.classList.add('hidden');
});

document.getElementById('checkout-form').addEventListener('submit', (e) => {
    if (cart.size === 0) {
        e.preventDefault();
        alert('Agrega productos al carrito.');
        return;
    }

    cart.forEach((item) => {
        const inputId = `items_${item.id}`;
        let input = document.getElementById(inputId);
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'items[][product_id]';
            input.value = item.id;
            input.id = inputId;
            e.target.appendChild(input);
        }
        const qty = document.createElement('input');
        qty.type = 'hidden';
        qty.name = 'items[][quantity]';
        qty.value = item.quantity;
        e.target.appendChild(qty);
        const price = document.createElement('input');
        price.type = 'hidden';
        price.name = 'items[][price]';
        price.value = item.price.toFixed(2);
        e.target.appendChild(price);
    });
});
</script>
@endsection

