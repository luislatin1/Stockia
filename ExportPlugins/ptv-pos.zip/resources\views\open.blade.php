@extends('layouts.app')

@section('title', 'Abrir Caja')

@section('content')
<div class="max-w-lg space-y-4">
    <h2 class="text-2xl font-bold text-gray-900">Abrir Caja</h2>

    <form method="POST" action="{{ route('ptvpos.open.store') }}" class="space-y-3">
        @csrf
        <div>
            <label class="block text-sm font-medium text-gray-700">Efectivo inicial</label>
            <input type="number" step="0.01" min="0" name="opening_cash" class="w-full rounded border border-gray-300 px-3 py-2">
        </div>
        <button class="rounded bg-emerald-600 px-4 py-2 text-sm font-semibold text-white">Guardar</button>
    </form>
</div>
@endsection

