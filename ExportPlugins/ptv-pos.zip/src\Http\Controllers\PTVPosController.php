<?php

namespace Stockia\PTVPos\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\InventoryMovement;
use App\Models\CompanyUser;

class PTVPosController extends Controller
{
    public function index()
    {
        return view('ptvpos::index');
    }

    public function pos()
    {
        return view('ptvpos::pos');
    }

    public function scan(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'barcode' => ['required', 'string', 'max:255'],
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'Barcode invalido.'], 422);
        }

        $companyId = (int) session('current_company_id');
        $warehouseId = (int) session('current_warehouse_id');

        $product = Product::where('company_id', $companyId)
            ->where('barcode', $request->barcode)
            ->with(['warehouses' => function ($query) use ($warehouseId) {
                $query->where('warehouses.id', $warehouseId);
            }])
            ->first();

        if (! $product) {
            return response()->json(['message' => 'Producto no encontrado.'], 404);
        }

        return response()->json([
            'id' => $product->id,
            'name' => $product->name,
            'price' => (float) $product->price,
            'stock' => (int) $product->stock,
        ]);
    }

    public function adminAuth(Request $request)
    {
        $request->validate([
            'password' => ['required', 'string'],
        ]);

        $companyId = (int) session('current_company_id');

        $adminUsers = CompanyUser::where('company_id', $companyId)
            ->whereIn('role', ['Admin', 'SuperAdmin'])
            ->with('user')
            ->get()
            ->pluck('user');

        foreach ($adminUsers as $user) {
            if ($user && Hash::check($request->password, $user->password)) {
                return response()->json(['ok' => true]);
            }
        }

        return response()->json(['ok' => false, 'message' => 'Clave de administrador invalida.'], 403);
    }

    public function checkout(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'items' => ['required', 'array'],
            'items.*.product_id' => ['required', 'integer'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
            'items.*.price' => ['required', 'numeric', 'min:0'],
            'cash_received' => ['required', 'numeric', 'min:0'],
            'document_type' => ['required', 'in:ticket,factura'],
            'admin_password' => ['nullable', 'string'],
        ]);

        $companyId = (int) session('current_company_id');
        $warehouseId = (int) session('current_warehouse_id');

        $items = collect($data['items'])->map(function ($item) {
            return [
                'product_id' => (int) $item['product_id'],
                'quantity' => (int) $item['quantity'],
                'price' => (float) $item['price'],
            ];
        });

        $productIds = $items->pluck('product_id')->unique()->values();
        $products = Product::where('company_id', $companyId)
            ->whereIn('id', $productIds)
            ->get()
            ->keyBy('id');

        $subtotal = 0.0;
        foreach ($items as $item) {
            if (! $products->has($item['product_id'])) {
                return back()->withErrors('Producto invalido.');
            }
            $subtotal += $item['price'] * $item['quantity'];
        }

        $taxTotal = round($subtotal * 0.13, 2);
        $total = round($subtotal + $taxTotal, 2);
        $cashReceived = round((float) $data['cash_received'], 2);

        if ($cashReceived < $total) {
            return back()->withErrors('El efectivo recibido no cubre el total.');
        }

        $changeAmount = round($cashReceived - $total, 2);

        DB::transaction(function () use ($companyId, $warehouseId, $items, $products, $subtotal, $taxTotal, $total, $cashReceived, $changeAmount, $data) {
            $sale = Sale::create([
                'company_id' => $companyId,
                'warehouse_id' => $warehouseId,
                'user_id' => auth()->id(),
                'status' => 'completed',
                'subtotal' => $subtotal,
                'tax_total' => $taxTotal,
                'total' => $total,
                'payment_method' => 'cash',
                'cash_received' => $cashReceived,
                'change_amount' => $changeAmount,
                'document_type' => $data['document_type'],
            ]);

            foreach ($items as $item) {
                $product = $products->get($item['product_id']);
                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $product->id,
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                    'subtotal' => $item['price'] * $item['quantity'],
                ]);

                InventoryMovement::create([
                    'company_id' => $companyId,
                    'warehouse_id' => $warehouseId,
                    'product_id' => $product->id,
                    'type' => 'out',
                    'quantity' => $item['quantity'],
                    'reference_type' => 'sale',
                    'reference_id' => $sale->id,
                    'user_id' => auth()->id(),
                ]);
            }
        });

        return redirect()->route('ptvpos.index')->with('success', 'Venta realizada.');
    }

    public function open()
    {
        return view('ptvpos::open');
    }

    public function storeOpen(Request $request): RedirectResponse
    {
        $request->validate([
            'opening_cash' => ['required', 'numeric', 'min:0'],
        ]);

        DB::table('pos_sessions')->insert([
            'company_id' => session('current_company_id'),
            'warehouse_id' => session('current_warehouse_id'),
            'user_id' => auth()->id(),
            'opening_cash' => $request->opening_cash,
            'opened_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->route('ptvpos.index')->with('success', 'Caja abierta.');
    }

    public function close()
    {
        return view('ptvpos::close');
    }

    public function storeClose(Request $request): RedirectResponse
    {
        $request->validate([
            'closing_cash' => ['required', 'numeric', 'min:0'],
        ]);

        DB::table('pos_sessions')
            ->where('company_id', session('current_company_id'))
            ->where('warehouse_id', session('current_warehouse_id'))
            ->whereNull('closed_at')
            ->orderByDesc('id')
            ->limit(1)
            ->update([
                'closing_cash' => $request->closing_cash,
                'closed_at' => now(),
                'updated_at' => now(),
            ]);

        return redirect()->route('ptvpos.index')->with('success', 'Caja cerrada.');
    }
}

